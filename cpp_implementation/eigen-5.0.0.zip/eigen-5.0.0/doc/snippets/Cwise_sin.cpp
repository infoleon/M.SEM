Array3d v(EIGEN_PI, EIGEN_PI / 2, EIGEN_PI / 3);
cout << v.sin() << endl;
