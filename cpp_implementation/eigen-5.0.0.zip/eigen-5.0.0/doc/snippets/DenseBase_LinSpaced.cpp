cout << VectorXi::LinSpaced(4, 7, 10).transpose() << endl;
cout << VectorXd::LinSpaced(5, 0.0, 1.0).transpose() << endl;
